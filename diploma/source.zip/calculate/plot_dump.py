﻿# ---------------------------------------------------------------------------------------------------
#
# принимаемые параметры: [имя_файла] скорость временные интервалы [-step:шаг -num -quiet -notitle]
#  имя_файла -- название файла с dump-ом, стандартно = 'data/morse.dump'. Не может принимать
#    значения из списка: ['True', 'False', '0', '1']
#  скорость -- логический параметр, отвечающий за отрисовку скоростей на графике.
#    Принимает значения из списка ['True', 'False', '0', '1'],
#    при значениях True и 1 -- скорости рисуются, иначе -- нет
#  временные интервалы -- значения timestep из файла, для которых нужно построить графики.
#    Возможны перечисления: 0 1 2 3   -- построит графики в моменты времени 0, 1, 2, 3;
#    интервалы: 0-10                  --                                    0, 1, ..., 10;
#    интервалы с шагом: 0-10,2        --                                    0, 2, 4, ..., 10;
#    и их различные комбинации: 0 1 10-20,2 25-1000,25
#  ключ -step:шаг задает стандартный шаг для интервалов временных значений, например,
#    0-10 -step:2 построит графики в моменты времени 0, 2, 4, ..., 10
#  ключ -num отвечает за простановку номеров атомов (номер берется по порядку появления в файле dump)
#  ключ -quiet отвечает за отключение вывода в консоль
#  ключ -notitle отвечает за показ подписи (шапки: времени и количества атомов) к рисунку
#
# с именем файла будет связана папка сохранения графиков: 'plots/' + измененное_имя_файла
#
# примеры использования:
#  python plot_dump.py False 50 100-250,25 350 400 500-510 -quiet
#  построит графики по данным из файла data/morse.dump в моменты времени
#  50, 100, 125, 150, 175, 200, 225, 250, 350, 400, 500, 501, 502, ..., 509, 510
#  без отрисовки скоростей и вывода текстовой информации в консоль.
#  Графики будут сохранены в папку 'plots/morse'
#
#  python plot_dump.py data/sec_10K.dump True 0-2000,500 2250-10000 12000-20000 11000 -defstep:250
#  построит графики по данным из файла data/sec_10K.dump в моменты времени
#  0, 500, 1000, 2000, 2250, ..., 9750, 10000, 11000, 12000, 12250, ..., 19750, 20000
#  с отрисовкой скоростей атомов.
#  Графики будут сохранены в папку 'plots/sec_10K'
#
# ---------------------------------------------------------------------------------------------------

from sys import argv
from re import sub, match
from matplotlib import pyplot as plt
import os

defstep = 1 # интервал между двумя последующими временными срезами
defchanged = False
number = False
out = True
title = True
file = ['data/morse.dump'] * 2

if not (argv[1] in ['True', 'False', '0', '1']):
    file = [argv[1]] * 2
    del argv[1]

while '/' in file[1]:
    file[1] = file[1].split('/')[-1]
while '\\' in file[1]:
    file[1] = file[1].split('\\')[-1]
if '.' in file[1]:
    file[1] = file[1].split('.')[0]

for each in argv[:]:
    if match(r'-step:[0-9]+', each):
        defstep = int(each.split(':')[1])
        defchanged = True
        argv.remove(each)
    if match(r'-num', each):
        number = True
        argv.remove(each)
    if match(r'-notitle', each):
        title = False
        argv.remove(each)
    if match(r'-quiet', each):
        print 'INFO: output disabled'
        out = False
        argv.remove(each)

if out & defchanged: print 'INFO: default step changed to %d' % defstep
if out & number: print 'INFO: enabled printing numbers'
if out & (not title): print 'INFO: disabled printing title'

velocity = {'True': True, 'False': False, '1': True, '0': False}.get(argv[1], False)
# определяем количество аргументов
if len(argv) < 3:
    # должно быть не меньше 2-х
    print 'ERR: not enough arguments'
    exit()
elif len(argv) > 3: 
    # если больше или равно 2-м, то собираем из них список
    times = argv[2:]
else:
    times = [argv[2]]
if out: print 'determining the time moments...'
timestep = []
for each in times:
    if match(r'[0-9]+-[0-9]+,[0-9]+', each):
        # если задан интервал значений, добавляем к списку timestep этот интервал
        # если задан шаг, то изменяем его
        begin = int(each.split('-')[0])
        end, step = map(int, each.split('-')[1].split(','))
        if (end < begin) & out:
            print 'WARN: an interval %d-%d will be ignored cause of %d < %d' % (begin, end, end, begin)
        end += step
        timestep += map(str, range(begin, end, step))
    elif match(r'[0-9]+-[0-9]+', each):
        begin, end = map(int, each.split('-'))
        if (end < begin) & out:
            print 'WARN: an interval %d-%d will be ignored cause of %d < %d' % (begin, end, end, begin)
        end += defstep
        timestep += map(str, range(begin, end, defstep))
    else:
        # иначе -- добавляем одно значение
        timestep.append(each)

if timestep == []:
    print 'ERR: nothing to plot'
    exit()

if out: print 'reading "%s" file...' % file[0]
f = open(file[0]).read()
for i in range(10):
    f = sub(' %d ' % i, ' %d.0 ' % i, sub(' %d ' % i, ' %d.0 ' % i, f))
    f = sub(' -%d ' % i, ' -%d.0 ' % i, sub(' -%d ' % i, ' -%d.0 ' % i, f))
f = sub(' \n', '\n', f)
lines = [line.rstrip() for line in f.split('\n')]

if out: print 'determining region...'
# определяем границы графика
region = map(lambda(x): float(x) + float(x) / abs(float(x)) * 10,
  lines[next(i for i in range(len(lines))
  if lines[i-1] == 'ITEM: BOX BOUNDS pp pp pp')].split(' '))

if out: print 'searching for time moments in file...'
# определяем строку, открывающую часть о данном моменте времени
timeline = []
for each in timestep:
    timeline.append(next(i for i in range(len(lines))
      if (lines[i-1] == 'ITEM: TIMESTEP') & (lines[i] == each)))

if out: print 'plotting...'
# оставляем строки с информацией о вихрях в момент времени timestep
dir = 'plots/%s' % file[1]
if not os.path.exists(dir):
    os.makedirs(dir)
    if out: print 'INFO: created directory %s' % dir
for k in range(len(timeline)):
    if out: print '  started: %s, %s' % (timestep[k], velocity)
    name = '%s/%s_%s.png' % (dir, timestep[k], velocity)

    if out: print '    getting data...'
    curr = lines[timeline[k]:]                       # curr начинается со строки = timestep
    begin = curr.index('ITEM: ATOMS x y vx vy') + 1  # нужные строки начнутся после шапки
    end = curr.index('ITEM: TIMESTEP') if 'ITEM: TIMESTEP' in curr else -1
      # и закончатся появлением следующего timestep либо концом файла
    curr  = curr[begin:end]
    if title: atom_num = lines[timeline[k] + 2]      # количество атомов в данный момент

    # разбиваем строки на 4 списка чисел
    for i in range(len(curr)):
        curr[i] = map(float, curr[i][:-1].split(' '))

    x, y, vx, vy = map(list, zip(*curr))
    if velocity:
        # переносим начало вектора скорости в центр соответствующего атома
        for i in range(len(vx)):
            vx[i] += x[i]
            vy[i] += y[i]
        vx, vy = zip(x, vx), zip(y, vy)

    if out: print '    plotting...'
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    if title: plt.title(r'Timestep: %s; num of atoms: %s' % (timestep[k], atom_num))
    plt.axis(region * 2)
    plt.plot(x, y, 'bo', linewidth=2, markersize=1.5)
    if number:
        if out: print '    printing numbers...'
        for i in range(len(x)):
            plt.text(x[i], y[i], str(i), fontsize=6)
    if velocity:
        if out: print '    drawing velocity vectors...'
        for i in range(len(vx)):
            plt.plot(vx[i], vy[i], 'g')
    if out: print '    saving...'
    plt.savefig(name)
    if out: print '  saved: %s\n' % name
    plt.clf()

﻿from matplotlib import pyplot as plt

lines = [line.rstrip() for line in open('data\morse_20K.rdf')]

# убираем комментарии из списка lines
comments = []
for i in lines:
    if i[0] == '#':
        comments.append(i)
for i in comments:
    lines.remove(i)

# определяем количество атомов = количество нужных строк с конца
b = int(lines[0].split(' ')[1])
del lines[0]

lines = lines[-b:]

# строки -> списки
for i in range(b):
    lines[i] = map(float, lines[i].split(' ')[1:3])

r, rdf = zip(*lines)
    
# график
plt.xlabel(r'$\vec{r}$')
plt.ylabel(r'$RDF$')
plt.axis([40, 100, 0, 1.5])
plt.plot(r, rdf, 'b', linewidth=2)
plt.plot([r[0], r[-1]], [1.0, 1.0], '#000000', linewidth=2)
plt.savefig('plots\morse_rdf.pdf')

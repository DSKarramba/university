#ifndef _DRAW_H
#define _DRAW_H

#ifdef __WIN32
	#include <windows.h>
	#include <gl/gl.h>
	#include <gl/glu.h>
#else
	#include <GL/gl.h>
	#include <GL/glx.h>
	#include <GL/glu.h>
#endif

#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include "struct.h"

extern void *we_malloc(size_t size);
extern void we_free(void *ptr);

/* we_initVertex: init vertex mass for drawCircle */
void we_initVertex(int seg);

/* we_vertexFree: free allocation memory */
void we_vertexFree(void);

/* we_drawCircle3f: drawing circle */
void we_drawCircle3f(float x, float y, float r);

/* we_drawCircle3f: drawing alpha circle */
void we_drawAlphaCircle3f(float x, float y, float r);

#endif

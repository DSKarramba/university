#include "font.h"

static int size = 256;   
static char *text;
extern GLuint base;

#ifdef __WIN32
void we_buildFont(we_font * font)
{
	HFONT w_font;
	extern HDC hDC;

    base = glGenLists(96);
    
    text = (char *) we_malloc(size*sizeof(char));
    
    switch (font->weight) {
        case WE_MEDIUM:
            font->weight = FW_MEDIUM;
            break;
        case WE_BOLD:
            font->weight = FW_BOLD;
            break;
    }

    w_font = CreateFont(-font->size, 0, 0, 0, font->weight, 0, 0, 0, 
        ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, 
        ANTIALIASED_QUALITY, FF_DONTCARE | DEFAULT_PITCH, font->name);
        
    if (!w_font) {
        w_font = CreateFont(-font->size, 0, 0, 0, font->weight, 0, 0, 0, 
            ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, 
            ANTIALIASED_QUALITY, FF_DONTCARE | DEFAULT_PITCH, "Arial");
        we_send_error(ERROR_LOAD_FONT);
    }

    SelectObject(hDC, w_font);
    wglUseFontBitmaps(hDC, 32, 96, base);

    /* C++ error mode on */
    if (sizeof('a') == sizeof(char))
        wglUseFontBitmaps(hDC, 32, 96, base);
}
#else
void we_buildFont(we_font * font)
{
	XFontStruct *x_font;    
	char buffer[128];
	char type[16];
	
	text = (char *) we_malloc(size*sizeof(char));

	switch (font->weight) {
		case WE_BOLD:
			sprintf(type, "bold");
			break;
		case WE_MEDIUM:
			sprintf(type, "medium");
			break;
	}

	sprintf(buffer, "-*-%s-%s-r-normal--%d-*-*-*-c-*-iso8859-1", font->name, type, 
		font->size);
    
    Display *dsp = XOpenDisplay(NULL);
    base = glGenLists(96); /* storage for 96 characters */       
    x_font = XLoadQueryFont(dsp, buffer);    
    if (x_font == NULL) {
        x_font = XLoadQueryFont(dsp, "fixed");    
        if (x_font == NULL){    
        	we_send_error(ERROR_LOAD_FONT);
            return;
        }    
    }    
    glXUseXFont(x_font->fid, 32, 96, base);    
    XFreeFont(dsp, x_font);  
}
#endif

void we_printf(float x, float y, const char *fmt, ...)
{
    /*
       нужна оптимизация скорости вывода текста
       рассмотреть все возможные варианты
       этот код медленные (грузит слабый процессор)
    */
    va_list ap;
    int n;

    if (fmt == NULL) 
        return;

    va_start(ap, fmt);
    n = vsnprintf(text, size, fmt, ap); 
    va_end(ap);    

    glRasterPos2f(x, y);
    glPushAttrib(GL_LIST_BIT);    
    glListBase(base - 32);    
    glCallLists(n, GL_UNSIGNED_BYTE, text);    
    glPopAttrib();  
}

void we_killFont(void)
{
    we_free(text);
}

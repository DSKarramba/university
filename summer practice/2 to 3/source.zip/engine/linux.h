#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <GL/gl.h>
#include <GL/glx.h>
#include <X11/extensions/xf86vmode.h>
#include <X11/keysym.h>
#include "struct.h"
#include "error.h"
#include "keyboard.h"

typedef struct {
    Display *dsp;
    int screen;
    Window wnd;
    Window root;
    GLXContext ctx;
    XSetWindowAttributes swa;
    Bool doubleBuffered;
    XF86VidModeModeInfo deskMode;
    XVisualInfo *vi;
    XWindowAttributes gwa;
    int fullscreen;
    int x, y, depth;
} GLWindow;

extern void we_resize(int width, int height, we_option *option);
extern void we_info();
extern void *we_malloc(size_t size);
extern void we_free(void *ptr);
extern void we_param(we_engine * engine);
extern uint we_ticks(void);

/* we_create_window: create engine window */
int we_create_window(we_engine * engine);

/* we_loop: main event system */
void we_loop(we_engine * engine);

/* we_kill: destroy window */
void we_kill(void);

/* we_render: rendering callback function */
void we_render(void (*param)(void));

/* we_init: opengl init function */
void we_init(void (*param)(void));

/* we_keyboard: keyboard callback function */
void we_keyboard(void (*param)(int));

/* we_quit: close program */
void we_quit(void);

/* we_window_mode: change window mode */
void we_window_mode(we_engine * engine);

/* we_send_keycode: sending keycode to engine */
void we_send_keycode(int keycode);

/* we_get_button: get ASCII code for keycode */
char * we_get_button(void);

/* we_update_window: update window param's */
void we_update_window(we_engine *engine);

/* we_update_caption: update window caption */
void we_update_caption(const char *fmt, ...);

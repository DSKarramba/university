#include "draw.h"

static int segment = 36;
static float *vertex;
static float *ver;

void we_initVertex(int seg)
{
    int j = 0;
    float i;

    segment = seg;

 	vertex = (float *) we_malloc((2*segment+2)*sizeof(float));
	ver = (float *) we_malloc((2*segment+2)*sizeof(float));

    /* инициализируем массив для единичного круга */
    for (i = 0; i <= 360.0f; i += (360.0f / segment)) {
        vertex[j++] = cos(i*M_PI/180.0f);
        vertex[j++] = sin(i*M_PI/180.0f);
    }
}

void we_vertexFree(void)
{
    we_free(vertex);
    we_free(ver);
}

void we_drawCircle3f(float x, float y, float r)
{
    int i;

    for (i = 0; i < 2*segment+2; i += 2) {
        ver[i] = vertex[i] * r + x;
        ver[i+1] = vertex[i+1] * r + y;
    }

    /* рисуем нашу окружность */
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, ver);
	glDrawArrays(GL_POLYGON, 0, segment+1);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void we_drawAlphaCircle3f(float x, float y, float r)
{
    /* подумать о надобности этой функции */
    GLfloat color[3];
    int i;

    for (i = 0; i < 2*segment+2; i += 2) {
        ver[i] = vertex[i] * r + x;
        ver[i+1] = vertex[i+1] * r + y;
    }

    glEnableClientState(GL_VERTEX_ARRAY);

    /* рисуем первую окружность */
    glVertexPointer(2, GL_FLOAT, 0, ver);
    glDrawArrays(GL_POLYGON, 0, segment+1);

    /* а теперь вторую (только контур) с прозрачностью */
    glGetFloatv(GL_CURRENT_COLOR, color);
    glColor4f(color[0], color[1], color[2], 0.5f);
    glDrawArrays(GL_LINE_LOOP, 0, segment+1);
    glColor4f(color[0], color[1], color[2], color[3]);

    glDisableClientState(GL_VERTEX_ARRAY);
}
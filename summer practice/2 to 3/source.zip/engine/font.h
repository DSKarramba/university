#ifndef _FONT_H
#define _FONT_H

#ifdef __WIN32
	#include <windows.h>
	#include <gl/gl.h>
	#include <gl/glu.h>
#else
	#include <GL/gl.h>
	#include <GL/glx.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "struct.h"
#include "error.h"

extern void *we_malloc(size_t size);
extern void we_free(void *ptr);

/* we_buildFont: init font */
void we_buildFont(we_font * font);

/* we_printf: output text */
void we_printf(float x, float y, const char *fmt, ...);

/* we_killFont: free using font */
void we_killFont(void);

#endif

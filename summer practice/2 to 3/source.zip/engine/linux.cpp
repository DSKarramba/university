#include "linux.h"

static int single_attribs[] = {
	GLX_RGBA,
	GLX_DEPTH_SIZE, 24,
	GLX_RED_SIZE, 4,
	GLX_GREEN_SIZE, 4,
	GLX_BLUE_SIZE, 4,
	None
};

static int double_attribs[] = {
	GLX_RGBA,
	GLX_DOUBLEBUFFER,
	GLX_DEPTH_SIZE, 24,
	GLX_RED_SIZE, 4,
	GLX_GREEN_SIZE, 4,
	GLX_BLUE_SIZE, 4,
	None
};

void (*render_callback)(void);
void (*opengl_callback)(void);
void (*keyboard_callback)(int);

GLint base;
static int done = 0;
static GLWindow glw;
static int last_keycode;
static int text_size = 128;
static char *buffer;

int we_create_window(we_engine * engine)
{
	static int count = 0;
	Atom wmDelete;
	XF86VidModeModeInfo **modes;
    int modeNum;
	int glx_major, glx_minor;
	int vme_major, vme_minor;
	int dspWidth, dspHeight;
	int bestMode = 0, i;

	char *env = getenv("DISPLAY");

	if (!(glw.dsp = XOpenDisplay(env))) {
		we_send_error(ERROR_OPEN_DISPLAY);
		return EXIT_FAILURE;
	}

	glw.screen = DefaultScreen(glw.dsp);
	if (glw.screen) {
		XCloseDisplay(glw.dsp);
		we_send_error(ERROR_OPEN_DISPLAY);
		return EXIT_FAILURE;
	}

	XF86VidModeQueryVersion(glw.dsp, &vme_major, &vme_minor);
    if (!count) 
    	printf("Supported XF86VidModeExtension version %d.%d\n", vme_major, vme_minor);
    XF86VidModeGetAllModeLines(glw.dsp, glw.screen, &modeNum, &modes);

    glw.deskMode = *modes[0];
    for (i = 0; i < modeNum; i++) {
        if ((modes[i]->hdisplay == engine->width) && 
            (modes[i]->vdisplay == engine->height))
            bestMode = i;
    }

	if (!glXQueryExtension(glw.dsp, 0, 0)) {
		XCloseDisplay(glw.dsp);
		we_send_error(ERROR_GLX_SUPPORT);
		return EXIT_FAILURE;
	}

	glXQueryVersion(glw.dsp, &glx_major, &glx_minor);
	if (!count)
		printf("Supported GLX version - %d.%d\n", glx_major, glx_minor);

	if (glx_major == 1 && glx_minor < 3) {
		XCloseDisplay(glw.dsp);
		we_send_error(ERROR_GLX_VERSION);
		return EXIT_FAILURE;
	}

	glw.vi = glXChooseVisual(glw.dsp, 0, double_attribs);
	if (!glw.vi) {
		glw.vi = glXChooseVisual(glw.dsp, 0, single_attribs);
		if (!glw.vi) {
			we_send_error(ERROR_CHOOSE_VISUAL);
			XCloseDisplay(glw.dsp);
			return EXIT_FAILURE;
		}
		we_send_info(INFO_SINGLE_BUFFER);
	}
	else
		we_send_info(INFO_DOUBLE_BUFFER);

	glw.root = RootWindow(glw.dsp, glw.vi->screen);
	glw.swa.colormap = XCreateColormap(glw.dsp, glw.root, glw.vi->visual, AllocNone);
	glw.swa.event_mask = ExposureMask | KeyPressMask | ButtonPressMask;

	if (engine->fullscreen) {
		XF86VidModeSwitchToMode(glw.dsp, glw.screen, modes[bestMode]);
        XF86VidModeSetViewPort(glw.dsp, glw.screen, 0, 0);
        dspWidth = modes[bestMode]->hdisplay;
        dspHeight = modes[bestMode]->vdisplay;
        if (engine->debug)
       		printf("> Fullscreen Mode: %dx%dx%d\n", dspWidth, dspHeight, glw.vi->depth);
        XFree(modes);

        glw.swa.override_redirect = 1;

        glw.wnd = XCreateWindow(glw.dsp, glw.root, 0, 0, dspWidth, dspHeight, 0, glw.vi->depth, InputOutput, glw.vi->visual, CWBorderPixel | CWColormap | CWEventMask | CWOverrideRedirect, &glw.swa);
        if (!glw.wnd) {
        	we_send_error(ERROR_CREATE_WINDOW);
			XCloseDisplay(glw.dsp);
			return EXIT_FAILURE;
        }

		XMapRaised(glw.dsp, glw.wnd);
        XGrabKeyboard(glw.dsp, glw.wnd, 1, GrabModeAsync, GrabModeAsync, CurrentTime);
        XGrabPointer(glw.dsp, glw.wnd, 1, ButtonPressMask, GrabModeAsync, GrabModeAsync, glw.wnd, None, CurrentTime);
	}
	else {
		dspWidth = engine->width;
		dspHeight = engine->height;

		glw.swa.border_pixel = 0;

		glw.wnd = XCreateWindow(glw.dsp, glw.root, 0, 0, dspWidth, dspHeight, 0, glw.vi->depth, InputOutput, glw.vi->visual, CWBorderPixel | CWColormap | CWEventMask, &glw.swa);
		if (!glw.wnd) {
			we_send_error(ERROR_CREATE_WINDOW);
			XCloseDisplay(glw.dsp);
			return EXIT_FAILURE;
		}

		if (engine->debug)
			printf("> Window mode: %dx%dx%d\n", engine->width, engine->height, glw.vi->depth);

		wmDelete = XInternAtom(glw.dsp, "WM_DELETE_WINDOW", True);
    	XSetWMProtocols (glw.dsp, glw.wnd, &wmDelete, 1);
    	XSetStandardProperties(glw.dsp, glw.wnd, engine->name, engine->name, None, NULL, 0, NULL);
    	XMapRaised(glw.dsp, glw.wnd);
	}

	glw.ctx = glXCreateContext(glw.dsp, glw.vi, 0, 1);
	if (!glw.ctx) {
		we_send_error(ERROR_CREATE_CONTEXT);
		XCloseDisplay(glw.dsp);
		return EXIT_FAILURE;
	}

	if (!glXMakeCurrent(glw.dsp, glw.wnd, glw.ctx)) {
		we_send_error(ERROR_DRAW_CONTEXT);
		glXDestroyContext(glw.dsp, glw.ctx);
		glw.ctx = 0;
		return EXIT_FAILURE;
	}

	if (opengl_callback)
		opengl_callback();

	count++;

	return EXIT_SUCCESS;
}

void we_loop(we_engine * engine)
{
	uint now = 0;
    uint start = 0;
    uint stop = 0;
    XEvent event;
	KeySym keysym;
	we_option *proj;
    
    if (engine->max_fps == 0 || engine->max_fps < 0)
        engine->max_fps = 60;
        
    stop = 1000 / engine->max_fps;
	
	buffer = (char *) we_malloc(text_size*sizeof(char));

	glw.fullscreen = engine->fullscreen;
	proj = &engine->proj;

	we_param(engine);
	we_info();

	if (we_create_window(engine))
		return;

	while (!done) {
		while (XPending(glw.dsp)) {
			XNextEvent(glw.dsp, &event);
			switch (event.type) {
				case Expose:
					XGetWindowAttributes(glw.dsp, glw.wnd, &glw.gwa);
					we_resize(glw.gwa.width, glw.gwa.height, proj);
					break;
				case KeyPress:
					XLookupKeysym(&event.xkey, 0);
					XLookupString(&event.xkey, buffer, sizeof(buffer), &keysym, 0);
					we_send_keycode(event.xkey.keycode);
					break;
				case ClientMessage:
					done = 1;
					break;
			}
		}
		now = we_ticks();
		if (render_callback && !done && (now - start > stop)) {
			start = we_ticks();
			render_callback();
			glXSwapBuffers(glw.dsp, glw.wnd);
		}

		usleep(1500);
	}

	we_free(buffer);
	we_kill();
}

void we_send_keycode(int keycode)
{
	last_keycode = keycode;
	if (keyboard_callback)
		keyboard_callback(keycode);
}

char * we_get_button(void)
{
	return buffer;
}

void we_update_window(we_engine *engine)
{
	XGetWindowAttributes(glw.dsp, glw.wnd, &glw.gwa);
	we_resize(glw.gwa.width, glw.gwa.height, &engine->proj);
}

void we_kill(void) 
{
	if (glw.ctx) {
        if (!glXMakeCurrent(glw.dsp, glw.wnd, glw.ctx)) {
			we_send_error(ERROR_DRAW_CONTEXT);
			glXDestroyContext(glw.dsp, glw.ctx);
			glw.ctx = 0;
		}
    }
    if (glw.fullscreen) {
        XF86VidModeSwitchToMode(glw.dsp, glw.screen, &glw.deskMode);
        XF86VidModeSetViewPort(glw.dsp, glw.screen, 0, 0);
    }
    /* test this function */
    XCloseDisplay(glw.dsp);
}

void we_window_mode(we_engine * engine)
{
	we_kill();
	engine->fullscreen = !engine->fullscreen;
	glw.fullscreen = !glw.fullscreen;
	we_create_window(engine);
}

void we_update_caption(const char *fmt, ...)
{
    va_list text;
    int count;
    XTextProperty wn;
    
    if (fmt == NULL)
        return ;
        
    va_start(text, fmt);
    count = vsnprintf(buffer, text_size, fmt, text); 
    va_end(text); 
    
    if (XStringListToTextProperty(&buffer, 1, &wn) == 0)
    	return ;

    XSetWMName(glw.dsp, glw.wnd, &wn);
    XFree(wn.value);
}

void we_render(void (*param)(void))
{
    render_callback = param;
}

void we_init(void (*param)(void))
{
	opengl_callback = param;
}

void we_keyboard(void (*param)(int))
{
	keyboard_callback = param;
}

void we_quit(void)
{
	done = 1;
}

#ifndef _ERROR_H
#define _ERROR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// прописать ошибки

enum {
	ERROR_NONE,
// linux
	ERROR_OPEN_DISPLAY,
	ERROR_GLX_VERSION,
	ERROR_GLX_SUPPORT,
	ERROR_CHOOSE_VISUAL,
	ERROR_DRAW_CONTEXT,
// windows
	ERROR_REGISTER_WINDOW,
	ERROR_CREATE_WINDOW,
	ERROR_CREATE_CONTEXT,
	ERROR_GETDC_CONTEXT,
	ERROR_CHOOSE_PIXELFORMAT,
	ERROR_SET_PIXELFORMAT,
	ERROR_MAKE_CONTEXT,
	ERROR_CLEAR_CONTEXT,
	ERROR_DELETE_CONTEXT,
	ERROR_FULLSCR_MODE,
// other
	ERROR_LOAD_FONT,
	ERROR_ALLOC_MEMORY
};

enum {
	INFO_DOUBLE_BUFFER,
	INFO_SINGLE_BUFFER
};

/* we_print_error: print engine error */
void we_print_error(void);

/* we_send_error: send error from system */
void we_send_error(int error);

/* we_get_error: get engine error */
int we_get_error(void);

/* we_print_info: print engine information */
void we_print_info(void);

/* we_send_info: send info from system */
void we_send_info(int info);

/* we_get_info: get engine information */
int we_get_info(void);

#endif

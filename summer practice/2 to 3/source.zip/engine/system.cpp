#include "system.h"

static char *engine_name = "Wrench Engine";
static char *engine_version = "0.2 (cut version)";
static char *engine_date = "27/08/2012";

static int FrameCount = 0;
static float NewCount = 0.0f, LastCount = 0.0f, FpsRate = 0.0f;

// static uint rdtsc = 0;

#ifdef __WIN32
void catch_crash(int signal)
{
    printf("segmentation violation!\n");
    //getch(); // ����� ��� ��������� ���������� ����������
    exit(3);
}
#else
void catch_crash(int signum)
{
	int i;
	int *callstack[128];
	int frame;
	char **str;

	frame = backtrace((void **)callstack, 128);
	str = backtrace_symbols((void* const*) callstack, frame);

	printf("> backtrace log:\n");
	for (i = 0; i < frame; i++)
		printf("  %s\n", str[i]);

	free(str);

	signal(signum, SIG_DFL);
	exit(3);
}
#endif

#ifdef __WIN32
void we_info(void)
{
	char buffer[256];
	int dwBuild, i;

	int dwVersion = GetVersion();
	int dwMajor = (LOBYTE(LOWORD(dwVersion)));
	int dwMinor = (HIBYTE(LOWORD(dwVersion)));
	
	signal(SIGSEGV, catch_crash);

	if (dwVersion < 0x80000000) {
		dwBuild = (DWORD)(HIWORD(dwVersion));
		sprintf(buffer, "Windows [Version %d.%d.%d]", dwMajor, dwMinor, dwBuild);
	}
	else if (dwMajor < 4){
		dwBuild = (DWORD)(HIWORD(dwVersion) & ~0x8000); 
		sprintf(buffer, "WIN32s [Version %d.%d.%d]", dwMajor, dwMinor, dwBuild);
	} 
	else {
		dwBuild = 0;
		sprintf(buffer, "Win95/Win98 [Version %d.%d.%d]", dwMajor, dwMinor, dwBuild);
	}
	printf("%s %s (%s)\n", engine_name, engine_version, engine_date);
	printf("Working at %s\n", buffer);
}
#else
void we_info(void)
{
	struct utsname _system;

	signal(SIGSEGV, catch_crash);
	
	printf("%s %s (%s)\n", engine_name, engine_version, engine_date);
	if (!uname(&_system))
		printf("Working at %s %s %s\n", _system.sysname, _system.release, _system.machine);
}
#endif

void we_about(char **name, char **version)
{
	*name = engine_name;
	*version = engine_version;
}

float we_getfps(void)
{
	NewCount = (float)we_ticks();
    if ((NewCount-LastCount) > 1000) {
        FpsRate = (FrameCount*1000) / (NewCount-LastCount);
        LastCount = NewCount;
        FrameCount = 0;
    }
    FrameCount++;
	return FpsRate;
}

uint we_ticks(void)
{
#ifdef _WIN32
	return timeGetTime();
#else
	struct timeval tv;
	gettimeofday(&tv, 0);
	return (tv.tv_sec*1000+tv.tv_usec/1000);
#endif
}

/*
uint we_rdtsc(void)
{
#ifdef _WIN32
	__asm {
		xor eax, eax
		xor ebx, ebx
		xor ecx, ecx
		xor edx, edx
		cpuid
		rdtsc
		lea edi, [rdtsc]
		mov dword ptr [edi + 0], eax
		mov dword ptr [edi + 4], edx
		xor eax, eax
	}
#else
	__asm__ volatile (
	    ".intel_syntax noprefix;"
	    "xor eax, eax;"
	    "xor edx, edx;"
	    "xor ecx, ecx;"
	    "xor edx, edx;"
	    "cpuid;"
	    "rdtsc;"
	    "lea edi, rdtsc;"
	    "mov dword ptr [edi + 0], eax;"
		"mov dword ptr [edi + 4], edx;"
		"xor eax, eax;"	
	);
#endif
	return rdtsc;
}
*/

void *we_malloc(size_t size)
{
	void *ptr;
	ptr = malloc(size);

	if (engine.debug) {
		printf("  [>] address of pointer %p\n", ptr);
		printf("  [+] allocating %lu bytes\n", (unsigned long) size);
	}

	if (!ptr) {
		we_send_error(ERROR_ALLOC_MEMORY);
		exit(-1);
	}

	return ptr;
}

void we_free(void *ptr)
{
	free(ptr);
	if (engine.debug)
		printf("  [+] free memory at %p\n", ptr);
}

void we_resize(int width, int height, we_option *option)
{
	/* возможно нужно переписать этот код */
    GLfloat param1;
	GLfloat n = option->aspect;
    param1 = (float)width/height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	if (width <= height)
		glOrtho(-n, n, -n/param1, n/param1, n, -n);
	else
		glOrtho(-n * param1, n * param1, -n, n, n, -n);

	gluPerspective(option->angle, param1, option->zNear, option->zFar);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void we_param(we_engine *engine)
{
	/* добавить больше обрабатываемых функций */
	const char* const short_options = "d";
    const struct option long_options[] = {
    	{"debug", 	0, NULL, 'd'},
    	{NULL, 		0, NULL, 0}
	};
	int next_option;
	
	do {
		next_option = getopt_long(engine->argc, engine->argv, short_options, long_options, NULL);
		
		switch (next_option) {
			case 'd':
				engine->debug = 1;
				printf("> Debug mode: [on]\n");
				break;
			case -1:
				break;
			default:
				abort();
		}
	}
	while (next_option != -1);
}

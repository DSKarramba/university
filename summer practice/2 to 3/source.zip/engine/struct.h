#ifndef _STRUCT_H
#define _STRUCT_H

typedef struct {
	float aspect;
	float angle;
	float zNear;
	float zFar;
} we_option;
/* perspective option */

typedef struct {
	char *name;
	char *appclass;
	int width;
	int height;
	int fullscreen;
	int debug;
	int argc;
	char **argv;
	we_option proj;
	int max_fps;
} we_engine;
/* engine struct */

typedef struct {
	int size;
	int weight;
	char *name;
} we_font;
/* font struct */

#ifdef __WIN32
    typedef unsigned __int64 uint;
#endif

#define WE_MEDIUM 		0
#define WE_BOLD			1
/* font param */

#endif

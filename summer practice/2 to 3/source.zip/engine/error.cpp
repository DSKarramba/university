#include "error.h"

static int last_error = 0;
static int last_info = 0;

// error
static char str_error[] = "> ERROR: %s\n";
static char *str_error_msg[] = {
	// linux error's
	"No error", 
	"Could not open display",
	"GLX 1.3 or greater necessary",
	"X Server no support GLX Extension",
	"Could't choose visual context",
	"Couldt release drawing context",

	// windows error's
	"Failed to register the Window class",
	"Window creation error",
	"Can't create a GL rendering context",
	"Can't create a GL device context",
	"Can't find a suitable PixelFormat",
	"Can't set the PixelFormat",
	"Can't ativate The GL Rendering Context",
	"Release of DC and RC failed",
	"Release Rendering Context Failed",
	"Fullscreen mode switch failed",

	// other error's
	"Problems with loading font",
	"Can't allocate memory"
};

// info
static char str_info[] = "> INFO: %s\n";
static char *str_info_msg[] = {
	"using double buffer",
	"double buffer is not supported, using single buffer"
};

void we_print_error(void)
{
	printf(str_error, str_error_msg[last_error]);
}

void we_send_error(int error)
{
	last_error = error;
}

int we_get_error(void)
{
	return last_error;
}

void we_print_info(void)
{
	printf(str_info, str_info_msg[last_info]);
}

void we_send_info(int info)
{
	last_info = info;
}

int we_get_info(void)
{
	return last_info;
}

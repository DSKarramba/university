#include "windows.h"

LRESULT CALLBACK WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
void (*render_callback)(void);
void (*opengl_callback)(void);
void (*keyboard_callback)(int);

static int done = 0;

static HINSTANCE hInstance;
static WNDCLASS wc;       
static MSG msg;
static HWND hWnd;
HDC hDC;
static HGLRC hRC; 
static PIXELFORMATDESCRIPTOR pfd;
static int iFormat;

static int last_keycode;
static int text_size = 128;
static char buffer[128];

static we_option proj;

GLint base;

LRESULT CALLBACK WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
    	case WM_CREATE:
        	return 0;
            
    	case WM_CLOSE:
        	PostQuitMessage(0);
        	return 0;

    	case WM_DESTROY:
			return 0;

		case WM_SIZE:
			we_resize(LOWORD(lParam), HIWORD(lParam), &proj);
			return 0;

		case WM_KEYDOWN:
            GetKeyNameText(lParam, buffer, 80);
            we_send_keycode(wParam);
        	return 0;

    	default:
        	return DefWindowProc (hWnd, message, wParam, lParam);
    }
}

int ChangeScreenResolution(int width, int height, int bpp)
{
    DEVMODE dm;

    memset(&dm, 0, sizeof(dm));

    dm.dmSize = sizeof(dm);
    dm.dmPelsWidth = width;
    dm.dmPelsHeight = height;
    dm.dmBitsPerPel = bpp;
    dm.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;

    if (ChangeDisplaySettings(&dm, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
        return 0;
    return 1;
}

int we_create_window(we_engine * engine)
{
    static int count = 0;
    int wx = 0, wy = 0;
    int width, height;
    DWORD dwStyle = WS_CAPTION | WS_VISIBLE | WS_SYSMENU;
    DWORD dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;

	hInstance = GetModuleHandle(NULL);

	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH) GetStockObject (BLACK_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = engine->appclass;
    
    if (count > 0) {
        DestroyWindow(hWnd);
        UnregisterClass(engine->appclass, hInstance);
    }

    if (!RegisterClass(&wc)) {
		we_send_error(ERROR_REGISTER_WINDOW);
		return EXIT_FAILURE;
	}

    if (engine->fullscreen) {
        wx = GetSystemMetrics(SM_CXSCREEN);
        wy = GetSystemMetrics(SM_CYSCREEN);
        
        if (!ChangeScreenResolution(wx, wy, 32)) {
            we_send_error(ERROR_FULLSCR_MODE);
            engine->fullscreen = !engine->fullscreen;
        }
        else {
            if (engine->debug)
                printf("> Fullscreen Mode: %dx%dx%d\n", wx, wy, 32);
            
            ShowCursor(0);
            dwExStyle = WS_EX_APPWINDOW;
            dwStyle = WS_POPUP;

            width = wx;
            height = wy;
            wx = wy = 0;
        }
    }
    else {
        if (engine->debug)
            printf("> Window mode: %dx%dx%d\n", engine->width, engine->height, 32);

        width = engine->width + GetSystemMetrics(SM_CXSIZEFRAME);
        height = engine->height + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CXSIZEFRAME);
        wx = GetSystemMetrics(SM_CXFULLSCREEN);
        wy = GetSystemMetrics(SM_CYFULLSCREEN);
        wx = (wx - width) / 2;
        wy = (wy - height) / 2;
        ShowCursor(1);
    }

    hWnd = CreateWindowEx(dwExStyle, engine->appclass, engine->name, 
        WS_CLIPSIBLINGS | WS_CLIPCHILDREN | dwStyle, wx, wy,
        width, height, 0, 0, hInstance, 0); 

	if (!hWnd) {
		we_send_error(ERROR_CREATE_WINDOW);
		return EXIT_FAILURE;
	}
	
	ShowWindow(hWnd, SW_SHOW);
	SetForegroundWindow(hWnd);
	SetFocus(hWnd);

	hDC = GetDC(hWnd);

	if (!hDC) {
		we_send_error(ERROR_GETDC_CONTEXT);
		return EXIT_FAILURE;
	}

    ZeroMemory (&pfd, sizeof(pfd));
    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 32;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(hDC, &pfd);

	if (!iFormat) {
		we_send_error(ERROR_CHOOSE_PIXELFORMAT);
		return EXIT_FAILURE;
	}

    if (!SetPixelFormat(hDC, iFormat, &pfd)) {
		we_send_error(ERROR_SET_PIXELFORMAT);
		return EXIT_FAILURE;
	}

    hRC = wglCreateContext(hDC);
	if (!hRC) {
		we_send_error(ERROR_CREATE_CONTEXT);
		return EXIT_FAILURE;
	}

    if (!wglMakeCurrent(hDC, hRC)) {
		we_send_error(ERROR_MAKE_CONTEXT);
		return EXIT_FAILURE;
	}

    if (opengl_callback)
	   opengl_callback();

    count++;

	return EXIT_SUCCESS;
}

void we_loop(we_engine * engine)
{
    uint now = 0;
    uint start = 0;
    uint stop = 0;
    
    if (engine->max_fps == 0 || engine->max_fps < 0)
        engine->max_fps = 60;
        
    stop = 1000 / engine->max_fps;
    
    // for using timeGetTime
    timeBeginPeriod(1);
    
    we_info();
    we_param(engine);
    
	proj = engine->proj;
	if (we_create_window(engine))
		return;

    if (!engine->fullscreen) {
        we_resize(engine->width, engine->height, &proj);
    }
	else
        we_resize(GetSystemMetrics(SM_CXSCREEN), 
            GetSystemMetrics(SM_CYSCREEN), &proj);

    while (!done) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT)
                done = 1;
            else {
                TranslateMessage (&msg);
                DispatchMessage (&msg);
            }
        }
        else {
            now = we_ticks();
            if (render_callback && !done && (now - start > stop)) {
                start = we_ticks();
                render_callback();
                SwapBuffers(hDC);
            }
        }
        
        // to offload the CPU
        Sleep(1);
    }
}

void we_send_keycode(int keycode)
{
	last_keycode = keycode;
	if (keyboard_callback)
		keyboard_callback(keycode);
}

char * we_get_button(void)
{
	return buffer;
}

void we_update_window(we_engine *engine)
{
    RECT rect;
    GetWindowRect(hWnd, &rect);
    int width = GetSystemMetrics(SM_CXSIZEFRAME);
    int height = GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CXSIZEFRAME);
    
    if (engine->fullscreen)
        we_resize(rect.right - rect.left, rect.bottom-rect.top, &engine->proj);
    else
        we_resize(rect.right - rect.left - width, rect.bottom-rect.top - height, 
            &engine->proj);
}

void we_kill(void)
{
    if (!wglMakeCurrent(hDC, NULL)) {
		we_send_error(ERROR_CLEAR_CONTEXT);
		return;
	}

    if (!wglDeleteContext(hRC)) {
		we_send_error(ERROR_DELETE_CONTEXT);
		return;
	}

    ReleaseDC(hWnd, hDC);
}

void we_quit(void)
{
	done = 1;
}

void we_window_mode(we_engine * engine)
{
	we_kill();
	engine->fullscreen = !engine->fullscreen;
	if (!engine->fullscreen)
	   ChangeDisplaySettings(0, 0);
	we_create_window(engine);
}

void we_update_caption(const char *fmt, ...)
{
    va_list text;
    int count;
    
    if (fmt == NULL)
        return ;
        
    va_start(text, fmt);
    count = vsnprintf(buffer, text_size, fmt, text); 
    va_end(text); 
    
    SetWindowText(hWnd, buffer);
}

void we_render(void (*param)(void))
{
    render_callback = param;
}

void we_init(void (*param)(void))
{
	opengl_callback = param;
}

void we_keyboard(void (*param)(int))
{
	keyboard_callback = param;
}

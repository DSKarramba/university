#include "vector.h"

class point {
public:
	point() 
	{
		pos = Vec2(0, 0, 0);
		vel = Vec2(0, 0, 0);
		acc = Vec2(0, 0, 0);
		radius = 1.0f;
		mass = 1.0f;
		charge = 1.0f;
	}

	/* using x,y */
	// set functions
	void SetPos(float x, float y, float z);
	void SetVel(float x, float y, float z);
	void SetAcc(float x, float y, float z);

	/* using vector */
	// set functions
	void SetPos(Vec2 a) { pos = a; }
	void SetVel(Vec2 a) { vel = a; }
	void SetAcc(Vec2 a) { acc = a; }
	// get functions
	Vec2 GetPos() { return pos; }
	Vec2 GetVel() { return vel; }
	Vec2 GetAcc() { return acc; }

	void operator = (const point& a)
	{
		pos = a.pos;
		vel = a.vel;
		acc = a.acc;
		radius = a.radius;
		mass = a.mass;
		charge = a.charge;
	}

	void move(float dt);

	Vec2 pos;
	Vec2 vel;
	Vec2 acc;
	float radius;
	float mass;
	float charge;
};

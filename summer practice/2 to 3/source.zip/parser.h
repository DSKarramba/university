#ifndef _PARSER_H
#define _PARSER_H

#include <stdio.h>
#include <string.h>

typedef struct {
    char *name;
    int number;  
} p_format;

enum {
	S_TEXT,
	S_COMMENT,
	S_DATA
};

#define T_COMMENT			'#'
#define T_END				'\n'
#define T_DATA				'='
#define T_NULL              '\0'

int parser_getparam(FILE *f, p_format *p, char *a);

#endif

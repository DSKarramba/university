#include "object.h"

void point::SetPos(float x, float y, float z)
{
	pos.x = x;
	pos.y = y;
	pos.z = z;
}

void point::SetVel(float x, float y, float z)
{
	vel.x = x;
	vel.y = y;
	vel.z = z;
}

void point::SetAcc(float x, float y, float z)
{
	acc.x = x;
	acc.y = y;
	acc.z = z;
}

void point::move(float dt)
{
	//pos += vel * dt;
	pos.x += vel.x * dt;
	pos.y += vel.y * dt;
	pos.z += vel.z * dt;
	//vel += acc * dt;
	vel.x += acc.x * dt;
	vel.y += acc.y * dt;
	vel.z += acc.z * dt;
}

//===================================//
//                                   //
// module:       File Parser         //
// author:       dr.FreeCX           //
// version:      0.1                 //
// last:         02/08/2012          //
//                                   //
//==================[ pinecrew ]=====//

#include "parser.h"

int parser_getparam(FILE *f, p_format *p, char *a)
{
	int c;
	int i = 0;
	int state = S_TEXT;
	char label[64];

	while ((c = fgetc(f)) != EOF) {
		if (c == T_END && state == S_DATA) {
			a[i] = T_NULL;
			i = 0;
			for (i = 0; p[i].name != NULL; i++)
				if (!strcmp(label, p[i].name))
					return p[i].number;
		}
		else if (c == T_DATA && state == S_TEXT) {
			label[i-1] = T_NULL;
			i = 0;
		}

		if (c == T_COMMENT)
			state = S_COMMENT;
		else if (c == T_DATA && state == S_TEXT)
			state = S_DATA;
		else if (c == T_END && state == S_COMMENT)
			state = S_TEXT;
		else if (c == T_END)
			state = S_TEXT;

		if (state == S_DATA && c != T_DATA) {
			a[i] = c;
			i++;
		}
		else if (state == S_TEXT && c != T_END) {
			label[i] = c;
			i++;
		}
	}

	if (c == EOF && state == S_DATA) {
		a[i] = T_NULL;
		i = 0;
		for (i = 0; p[i].name != NULL; i++)
			if (!strcmp(label, p[i].name))
				return p[i].number;
	}
	
	return -1;
}
